import java.util.*;
import java.io.*;

// Interface do jogo
interface Jogo {
    void iniciar();
    void jogar();
    void encerrar();
}

// Classe abstrata Carta
abstract class Carta {
    protected String nome;
    protected boolean revelada;

    public Carta(String nome) {
        this.nome = nome;
        this.revelada = false;
    }

    public String getNome() {
        return nome;
    }

    public boolean estaRevelada() {
        return revelada;
    }

    public void revelar() {
        revelada = true;
    }

    public void esconder() {
        revelada = false;
    }

    public abstract void mostrar();
}

// Classe concreta de carta
class CartaMemoria extends Carta {
    public CartaMemoria(String nome) {
        super(nome);
    }

    @Override
    public void mostrar() {
        if (revelada) {
            System.out.print("[" + nome + "]");
        } else {
            System.out.print("[X]");
        }
    }
}

// Implementação do jogo da memória
public class JogoMemoria implements Jogo {
    private List<Carta> cartas;
    private Scanner scanner;
    private int erros;
    private int tentativas;

    public JogoMemoria() {
        cartas = new ArrayList<>();
        scanner = new Scanner(System.in);
        erros = 0;
        tentativas = 0;
    }

    @Override
    public void iniciar() {
        List<String> nomes = Arrays.asList("A", "B", "C", "D", "E", "F");
        for (String nome : nomes) {
            cartas.add(new CartaMemoria(nome));
            cartas.add(new CartaMemoria(nome));
        }
        Collections.shuffle(cartas);
        System.out.println("\nBem-vindo ao Jogo da Memória (Terminal)!\n");
    }

    @Override
    public void jogar() {
        while (!todasReveladas()) {
            mostrarCartas();

            System.out.print("\nEscolha a primeira carta (0 a " + (cartas.size() - 1) + "): ");
            int i1 = scanner.nextInt();

            if (i1 < 0 || i1 >= cartas.size() || cartas.get(i1).estaRevelada()) {
                System.out.println("Carta inválida ou já revelada. Tente novamente.\n");
                continue;
            }

            System.out.print("Escolha a segunda carta: ");
            int i2 = scanner.nextInt();

            if (i2 < 0 || i2 >= cartas.size() || i2 == i1 || cartas.get(i2).estaRevelada()) {
                System.out.println("Carta inválida ou já revelada. Tente novamente.\n");
                continue;
            }

            cartas.get(i1).revelar();
            cartas.get(i2).revelar();
            mostrarCartas();

            tentativas++;

            if (!cartas.get(i1).getNome().equals(cartas.get(i2).getNome())) {
                System.out.println("Não é um par!\n");
                cartas.get(i1).esconder();
                cartas.get(i2).esconder();
                erros++;
            } else {
                System.out.println("Par encontrado!\n");
            }
        }
    }

    @Override
    public void encerrar() {
        System.out.println("\nParabéns! Você finalizou o jogo com " + erros + " erros e " + tentativas + " tentativas.");
        salvarRanking();
    }

    private boolean todasReveladas() {
        for (Carta c : cartas) {
            if (!c.estaRevelada()) return false;
        }
        return true;
    }

    private void mostrarCartas() {
        for (int i = 0; i < cartas.size(); i++) {
            System.out.print(i + ": ");
            cartas.get(i).mostrar();
            System.out.print("  ");
            if ((i + 1) % 4 == 0) System.out.println();
        }
        System.out.println();
    }

    private void salvarRanking() {
        try (FileWriter fw = new FileWriter("ranking.txt", true)) {
            System.out.print("Digite seu nome para salvar no ranking: ");
            String nome = scanner.next();
            fw.write(nome + " - Tentativas: " + tentativas + " | Erros: " + erros + "\n");
            System.out.println("Ranking salvo com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao salvar ranking.");
        }
    }
    public static void main(String[] args) {
        Jogo jogo = new JogoMemoria();
        jogo.iniciar();
        jogo.jogar();
        jogo.encerrar();
    }
}